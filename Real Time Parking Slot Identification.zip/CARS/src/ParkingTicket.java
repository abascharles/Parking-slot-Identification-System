
import java.util.Date;

public class ParkingTicket {
    private Vehicle vehicle;
    private Date startTime;
    private Date endTime;
    private boolean paid;

    public ParkingTicket(Vehicle vehicle, Date startTime) {
        this.vehicle = vehicle;
        this.startTime = startTime;
        this.endTime = null;
        this.paid = false;
    }

    public double calculateFee(Date endTime) {
        long duration = endTime.getTime() - this.startTime.getTime();
        double hours = (double) duration / (1000 * 60 * 60);
        return hours * this.vehicle.getRate();
    }

    public boolean payTicket(double amount) {
        if (this.paid) {
            System.out.println("Ticket has already been paid");
            return false;
        } else {
            System.out.println("Ticket paid: " + amount);
            this.paid = true;
            this.endTime = new Date();
            return true;
        }
    }

    public Vehicle getVehicle() {
        return this.vehicle;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public boolean isPaid() {
        return this.paid;
    }

    public static void main(String[] args) {
        Vehicle car = new Vehicle("ABC-123", 5.0);
        ParkingTicket ticket = new ParkingTicket(car, new Date());
        try {
            Thread.sleep(5000); // Simulate parking for 5 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        double fee = ticket.calculateFee(new Date());
        System.out.println("Parking fee: " + fee);
        ticket.payTicket(fee);
    }

    private static class Vehicle {

        public Vehicle() {
        }

        private Vehicle(String abC123, double d) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private double getRate() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}